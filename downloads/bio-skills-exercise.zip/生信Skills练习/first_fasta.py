from pathlib import Path
import csv
from Bio import SeqIO
from Bio.SeqUtils import gc_fraction

root = Path(__file__).resolve().parent
source = root / "data" / "demo.fasta"
output = root / "results" / "sequence_summary.csv"
rows = []
for record in SeqIO.parse(source, "fasta"):
    sequence = str(record.seq).upper()
    if not sequence or set(sequence) - set("ATGC"):
        raise ValueError(f"Invalid demo sequence: {record.id}")
    rows.append([record.id, len(sequence),
                 f"{gc_fraction(sequence) * 100:.2f}"])
if not rows:
    raise ValueError("No FASTA records found")
output.parent.mkdir(parents=True, exist_ok=True)
with output.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.writer(f)
    writer.writerow(["sequence_id", "length", "gc_percent"])
    writer.writerows(rows)
print(output)

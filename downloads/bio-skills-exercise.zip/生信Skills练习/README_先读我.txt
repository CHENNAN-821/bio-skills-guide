﻿生信 AI Skills 新手教程 配套练习

先解压到自己选定的练习文件夹，再打开教程第 13 至 15 页。
已有 Python 的读者不用重复安装 Python。

Windows PowerShell 在解压后的文件夹中逐条执行：
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install biopython
.\.venv\Scripts\python.exe first_fasta.py

macOS / Linux：
python3 -m venv .venv
.venv/bin/python -m pip install biopython
.venv/bin/python first_fasta.py

data/demo.fasta 是人为编写的三条教学序列，不代表真实实验。
脚本仅接受非空的 ATGC 序列，真实含 N 等模糊碱基的文件应另行确定处理规则。
结果写入 results/sequence_summary.csv，不修改输入。再次运行会更新这个结果文件。
用 expected_summary.csv 对照长度和 GC 比例，不要只看有没有报错。

脚本由本教程编写，使用 Biopython 的 SeqIO 与 gc_fraction 接口。
Biopython 官网：https://biopython.org/
技能参考：https://github.com/K-Dense-AI/scientific-agent-skills/tree/main/skills/biopython
本练习脚本和人为序列可以复制、修改并分享，请保留这份说明。
